// RAW ATAR Calculator logic
const ATAR_CSV_2025 = `ATAR,minAgg,maxAgg
99.95,211.19,230
99.90,207.54,211.18
99.85,205.58,207.53
99.80,204.55,205.57`;
function parseCSV(text){const lines=text.trim().split(/?
/);const header=lines[0].split(',');const rows=[];for(let i=1;i<lines.length;i++){const parts=lines[i].split(',');rows.push({atar:parseFloat(parts[0]),minAgg:parseFloat(parts[1]),maxAgg:parseFloat(parts[2])});}return rows;}
let atarTable=parseCSV(ATAR_CSV_2025);
function fmt(n){return Number.isFinite(n)?n.toFixed(2):'—';}
function findATAR(agg){for(const r of atarTable){if(agg>=r.minAgg&&agg<=r.maxAgg)return r.atar;}return null;}
function calculate(){const p1=parseFloat(document.getElementById('p1').value);const p2=parseFloat(document.getElementById('p2').value);const p3=parseFloat(document.getElementById('p3').value);const p4=parseFloat(document.getElementById('p4').value);const inc1=parseFloat(document.getElementById('inc1').value)||0;const inc2=parseFloat(document.getElementById('inc2').value)||0;const agg=p1+p2+p3+p4+inc1+inc2;document.getElementById('agg').textContent=fmt(agg);const atar=findATAR(agg);document.getElementById('atar').textContent=fmt(atar);}document.getElementById('calc-btn').addEventListener('click',calculate);