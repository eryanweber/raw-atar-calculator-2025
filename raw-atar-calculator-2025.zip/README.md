# RAW ATAR Calculator (2025)

This repo hosts a static site for calculating VCE RAW ATAR using VTAC scaled scores.

## How to publish on GitHub Pages
1. Create a repo named `raw-atar-calculator-2025`.
2. Push these files to the root.
3. Enable GitHub Pages: Settings → Pages → Deploy from branch → Branch: main → Folder: /(root).
4. Your site will be live at: https://eryanweber.github.io/raw-atar-calculator-2025/
